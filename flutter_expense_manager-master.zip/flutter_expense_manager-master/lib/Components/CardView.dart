import 'package:flutter/material.dart';
import 'package:expense_manager/Model/CardModel.dart';

class CardView extends StatefulWidget {
  final CardModel card;

  const CardView(this.card, {Key? key}) : super(key: key);

  @override
  _CardViewState createState() => _CardViewState();
}

class _CardViewState extends State<CardView> {
  bool isHidden = true;

  // 🔥 MASK CARD NUMBER
  String getMaskedNumber(String number) {
    if (!isHidden) return number;

    String last4 = number.substring(number.length - 4);
    return "XXXX XXXX XXXX $last4";
  }

  // 🔥 CURRENCY SYMBOL (CASE-INSENSITIVE)
  String getCurrencySymbol(String currency) {
    String cur = currency.trim().toUpperCase();

    switch (cur) {
      case "INR":
        return "₹";
      case "USD":
        return "\$";
      case "EUR":
        return "€";
      case "GBP":
        return "£";
      case "JPY":
        return "¥";
      default:
        return currency; // fallback
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isHidden = !isHidden;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: LinearGradient(
            colors: [Colors.black, Colors.grey.shade900],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [

            // 🔥 TOP ROW
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

                // 🔴🟠 MASTERCARD LOGO
                SizedBox(
                  width: 60,
                  height: 30,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 18,
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: const BoxDecoration(
                            color: Colors.orange,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // 💰 BALANCE + SYMBOL
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [

                    Text(
                      widget.card.available.toString(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(width: 5),

                    Text(
                      getCurrencySymbol(widget.card.currency),
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            // 💳 CARD NAME
            Text(
              widget.card.name,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 18,
              ),
            ),

            // 💳 CARD NUMBER
            Text(
              getMaskedNumber(widget.card.number),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}