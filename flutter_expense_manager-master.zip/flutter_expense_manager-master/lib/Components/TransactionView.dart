import 'package:expense_manager/Model/TransactionModel.dart';
import 'package:flutter/material.dart';

class TransactionView extends StatefulWidget {
  final TransactionModel transaction;

  const TransactionView({Key? key, required this.transaction}) : super(key: key);

  @override
  State<TransactionView> createState() => _TransactionViewState();
}

class _TransactionViewState extends State<TransactionView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [

          // LEFT SIDE
          Row(
            children: [
              widget.transaction.type == "-"
                  ? const Icon(Icons.arrow_upward, color: Colors.red)
                  : const Icon(Icons.arrow_downward, color: Colors.green),

              const SizedBox(width: 10),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.transaction.name,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),

                  // DATE
                  Text(
                    "${widget.transaction.date.day}/${widget.transaction.date.month}/${widget.transaction.date.year}",
                    style: const TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ],
          ),

          // RIGHT SIDE
          Row(
            children: [
              Text(
                "${widget.transaction.type}${widget.transaction.price}",
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(width: 5),
              Text(
                widget.transaction.currency,
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}