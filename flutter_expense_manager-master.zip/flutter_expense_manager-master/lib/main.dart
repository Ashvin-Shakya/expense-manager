import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:expense_manager/Components/CardList.dart';
import 'package:expense_manager/Components/TransactionView.dart';
import 'package:expense_manager/Model/TransactionModel.dart';
import 'package:expense_manager/Pages/AddCardPage.dart';
import 'package:expense_manager/Pages/ExpensePage.dart';
import 'package:expense_manager/Providers/CardProvider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => CardProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(238, 241, 242, 1),

      // 🔥 DRAWER
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                "Expense Manager",
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text("Home"),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.add),
              title: const Text("Add Expense"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => AddCardPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.list),
              title: const Text("View Expenses"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ExpensePage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("Logout"),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Logged out")),
                );
              },
            ),
          ],
        ),
      ),

      appBar: AppBar(
        title: const Text(
          "Expense Manager",
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: const Color.fromRGBO(238, 241, 242, 1),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: Colors.black45),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddCardPage()),
              );
            },
          )
        ],
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Consumer<CardProvider>(
            builder: (context, provider, child) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  // 🔥 CARD SECTION
                  provider.getCardLength() > 0
                      ? SizedBox(
                    height: 210,
                    child: CardList(cards: provider.allCards),
                  )
                      : Container(
                    height: 210,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Center(
                      child: Text(
                        "Add your new card using + button",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 25),

                  // 🔥 TRANSACTIONS (CONDITION)
                  if (provider.getCardLength() > 0) ...[

                    const Text(
                      "Last Transactions",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.black45,
                      ),
                    ),

                    const SizedBox(height: 10),

                    TransactionView(
                      transaction: TransactionModel(
                        id: 1,
                        name: "Shopping",
                        price: 1000,
                        type: "-",
                        currency: "₹",
                        date: DateTime.now(),
                      ),
                    ),

                    TransactionView(
                      transaction: TransactionModel(
                        id: 2,
                        name: "Salary",
                        price: 1000,
                        type: "+",
                        currency: "₹",
                        date: DateTime.now(),
                      ),
                    ),

                  ] else ...[

                    // 🔥 NO TRANSACTION MESSAGE
                    const Text(
                      "No transactions yet",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}