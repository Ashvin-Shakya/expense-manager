import 'package:flutter/material.dart';
import '../Model/CardModel.dart';

class CardProvider extends ChangeNotifier {

  final List<CardModel> _cards = [];

  List<CardModel> get allCards => _cards;

  void addCard(CardModel card) {
    _cards.add(card);
    notifyListeners();
  }

  void removeCard(CardModel card) {
    _cards.remove(card);
    notifyListeners();
  }

  int getCardLength() {
    return _cards.length;
  }

  // 🔥 ADD THIS FUNCTION (THIS WAS MISSING)
  int getTotalBalance() {
    int total = 0;

    for (var card in _cards) {
      total += card.available;
    }

    return total;
  }
}