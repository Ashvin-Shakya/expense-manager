import 'package:expense_manager/Model/CardModel.dart';
import 'package:expense_manager/Providers/CardProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddCardPage extends StatefulWidget {
  const AddCardPage({super.key});

  @override
  State<AddCardPage> createState() => _AddCardPageState();
}

class _AddCardPageState extends State<AddCardPage> {

  final TextEditingController nameController = TextEditingController();
  final TextEditingController numberController = TextEditingController();
  final TextEditingController bankNameController = TextEditingController();
  final TextEditingController availableController = TextEditingController();
  final TextEditingController currencyController = TextEditingController();

  void onAdd() {
    if (nameController.text.isEmpty ||
        numberController.text.isEmpty ||
        bankNameController.text.isEmpty ||
        availableController.text.isEmpty ||
        currencyController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    final card = CardModel(
      id: DateTime.now().millisecondsSinceEpoch,
      name: nameController.text,
      number: numberController.text,
      bankName: bankNameController.text,
      available: int.tryParse(availableController.text) ?? 0,
      currency: currencyController.text,
    );

    Provider.of<CardProvider>(context, listen: false).addCard(card);

    Navigator.pop(context);
  }

  @override
  void dispose() {
    nameController.dispose();
    numberController.dispose();
    bankNameController.dispose();
    availableController.dispose();
    currencyController.dispose();
    super.dispose();
  }

  Widget buildInput(TextEditingController controller, String hint, TextInputType type) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: TextField(
        controller: controller,
        keyboardType: type,
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.grey),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(238, 241, 242, 1),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Add Card", style: TextStyle(color: Colors.black)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black45, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(15),
          child: Column(
            children: [
              buildInput(nameController, "Card name", TextInputType.text),
              const SizedBox(height: 15),

              buildInput(numberController, "Card Number", TextInputType.number),
              const SizedBox(height: 15),

              buildInput(bankNameController, "Bank Name", TextInputType.text),
              const SizedBox(height: 15),

              buildInput(availableController, "Available Balance", TextInputType.number),
              const SizedBox(height: 15),

              buildInput(currencyController, "Currency", TextInputType.text),
              const SizedBox(height: 20),

              MaterialButton(
                elevation: 0,
                minWidth: double.infinity,
                padding: const EdgeInsets.all(15),
                color: Colors.blue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                onPressed: onAdd,
                child: const Text(
                  'Add',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}