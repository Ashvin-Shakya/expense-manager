import 'package:flutter/material.dart';

class ExpensePage extends StatelessWidget {
  const ExpensePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Expenses"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(15),
        children: [
          tile("Food", "₹500"),
          tile("Transport", "₹300"),
          tile("Shopping", "+₹1000"),
          tile("Recharge", "₹200"),
        ],
      ),
    );
  }

  Widget tile(String title, String amount) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(amount),
        ],
      ),
    );
  }
}